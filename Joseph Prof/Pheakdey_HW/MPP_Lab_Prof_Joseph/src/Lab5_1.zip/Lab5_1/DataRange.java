package Lab5_1;

public final class DataRange {

}
