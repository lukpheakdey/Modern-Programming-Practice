package ExtraCredit;

public interface IProduct {
	double getPrice();
}
