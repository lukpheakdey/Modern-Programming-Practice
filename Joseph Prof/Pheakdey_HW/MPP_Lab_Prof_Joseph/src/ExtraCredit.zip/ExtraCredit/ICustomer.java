package ExtraCredit;

public interface ICustomer {
	
	CreditRating getCreditRating();
	void setCreditRating(CreditRating creditRating);
	
}
