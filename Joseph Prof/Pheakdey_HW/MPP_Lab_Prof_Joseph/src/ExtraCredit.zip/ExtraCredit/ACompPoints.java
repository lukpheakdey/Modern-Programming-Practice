package ExtraCredit;

public abstract class ACompPoints implements ICompPoints{

	public ACompPoints() {
		
	}
	public abstract double getPoints();
}
