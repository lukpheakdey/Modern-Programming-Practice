package ExtraCredit;

public interface ICompPoints {
	double getPoints();
}
