package ExtraCredit;

public class Audio_VideoPoints extends ACompPoints{
	
	private double points;
	
	public Audio_VideoPoints() {
		points= 0.5;
	}

	@Override
	public double getPoints() {
		return points;
	}
}
