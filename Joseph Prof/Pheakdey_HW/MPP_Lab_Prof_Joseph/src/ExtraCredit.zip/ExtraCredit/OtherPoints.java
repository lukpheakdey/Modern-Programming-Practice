package ExtraCredit;

public class OtherPoints extends ACompPoints{
private double points;
	
	public OtherPoints() {
		points=0.25;
	}

	@Override
	public double getPoints() {
		return points;
	}
}
